/*
Script prática linguagem DML
Curso bootcamp de Engenheiro de Dados IGTI
Professora: Fernanda Farinelli
*/

USE livraria;


INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(1,4);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(2,3);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(3,2);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(4,1);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(5,5);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(6,7);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(6,8);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(7,9);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(8,10);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(10,11);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(11,11);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(12,11);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(13,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(14,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(15,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(16,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(17,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(18,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(19,13);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(22,14);
INSERT INTO `livraria`.`autoria`(`id_livro`,`idautor`) VALUES(23,14);
