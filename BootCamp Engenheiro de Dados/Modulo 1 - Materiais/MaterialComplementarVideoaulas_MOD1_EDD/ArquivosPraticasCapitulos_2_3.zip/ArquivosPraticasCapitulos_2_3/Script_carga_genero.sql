/*
Script prática linguagem DML
Curso bootcamp de Engenheiro de Dados IGTI
Professora: Fernanda Farinelli

Carga na tabela genero.

Deve ser executado somente ANTES da carga na tabela Livro

*/

USE livraria;

INSERT INTO livraria.genero(idgenero,descricao) VALUES (1,"Espiritualismo");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (2,"Infanto-Juvenil");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (3,"Economia");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (4,"Medicina");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (5,"Romance");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (6,"Historia");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (7,"Fantasia");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (8,"Auto-Ajuda");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (9,"Informática");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (10,"Comédia");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (11,"Economia");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (12,"Saúde");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (13,"Nutrição");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (14,"Matemática");
INSERT INTO livraria.genero(idgenero,descricao) VALUES (15,"Astronomia");


